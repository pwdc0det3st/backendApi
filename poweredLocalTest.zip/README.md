# backendApi
A lambda function, that act as a backend controller. It registers customer prospects from a form into mail chimp audience.
